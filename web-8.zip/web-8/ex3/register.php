<?php
// Проверяем, что форма была отправлена
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Получаем данные из формы
    $fullname = $_POST['fullname'];
    $login = $_POST['login'];
    $password = $_POST['password'];
    $birthdate = $_POST['birthdate'];

    // Простая проверка заполнения всех полей
    if (empty($fullname) || empty($login) || empty($password) || empty($birthdate)) {
        echo "Пожалуйста, заполните все поля!";
        exit();
    }

    // Здесь должно быть подключение к базе данных
    // Пример подключения к MySQL:
    $servername = "localhost";
    $username = "root";
    $password_db = "";
    $dbname = "users_db";

    try {
        // Создаем подключение
        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password_db);
        // Устанавливаем режим обработки ошибок
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Подготавливаем SQL запрос
        $sql = "INSERT INTO users (fullname, login, password, birthdate) 
                VALUES (:fullname, :login, :password, :birthdate)";
        
        $stmt = $conn->prepare($sql);
        
        // Привязываем параметры
        $stmt->bindParam(':fullname', $fullname);
        $stmt->bindParam(':login', $login);
        // В реальном проекте пароль нужно хешировать
        $stmt->bindParam(':password', $password);
        $stmt->bindParam(':birthdate', $birthdate);

        // Выполняем запрос
        $stmt->execute();

        echo "Регистрация успешно завершена!";
    }
    catch(PDOException $e) {
        echo "Ошибка: " . $e->getMessage();
    }

    // Закрываем соединение
    $conn = null;
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Результат регистрации</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h1>Результат регистрации</h1>
        <p><a href="index.html">Вернуться на главную</a></p>
    </div>
</body>
</html>