// Праздничные дни (месяц, день)
const holidays = [
    [0, 1],  // Новый год
    [0, 7],  // Рождество
    [2, 8],  // 8 марта
    [4, 1],  // 1 мая
    [4, 9],  // 9 мая
    [5, 12], // День России
    [10, 4]  // День народного единства
];

function createCalendar(month, year) {
    // Получаем первый день месяца
    const firstDay = new Date(year, month, 1);
    // Получаем последний день месяца
    const lastDay = new Date(year, month + 1, 0);

    const calendarBody = document.getElementById('calendar-body');
    calendarBody.innerHTML = '';

    let date_num = 1;
    let firstDayOfWeek = firstDay.getDay() || 7; // Преобразуем 0 (воскресенье) в 7

    // Создаем календарь
    for (let i = 0; date_num <= lastDay.getDate(); i++) {
        const row = document.createElement('tr');
        
        for (let j = 1; j <= 7; j++) {
            const cell = document.createElement('td');
            
            if (i === 0 && j < firstDayOfWeek) {
                // Пустые ячейки до первого дня месяца
                cell.textContent = '';
            } else if (date_num <= lastDay.getDate()) {
                cell.textContent = date_num;
                
                // Проверяем выходные
                if (j === 6 || j === 7) {
                    cell.classList.add('weekend');
                }
                
                // Проверяем праздники
                if (holidays.some(h => h[0] === month && h[1] === date_num)) {
                    cell.classList.add('holiday');
                }
                
                date_num++;
            }
            
            row.appendChild(cell);
        }
        
        calendarBody.appendChild(row);
    }
}

// Функция для обработки нажатия кнопки "Показать"
function showCalendar() {
    const month = parseInt(document.getElementById('month').value);
    const year = parseInt(document.getElementById('year').value);
    
    if (isNaN(year) || year < 1900 || year > 2100) {
        alert('Пожалуйста, введите год от 1900 до 2100');
        return;
    }
    
    createCalendar(month, year);
}

// Инициализация календаря при загрузке страницы
document.addEventListener('DOMContentLoaded', function() {
    const currentDate = new Date();
    const currentMonth = currentDate.getMonth();
    const currentYear = currentDate.getFullYear();
    
   