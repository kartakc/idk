document.addEventListener('DOMContentLoaded', function() {
    const table = document.querySelector('table');
    
    // Создаем строки таблицы умножения
    for (let i = 1; i <= 10; i++) {
        const row = document.createElement('tr');
        
        // Добавляем первую ячейку с множителем
        const th = document.createElement('th');
        th.textContent = i;
        row.appendChild(th);
        
        // Добавляем результаты умножения
        for (let j = 0; j <= 10; j++) {
            const td = document.createElement('td');
            td.textContent = i * j;
            row.appendChild(td);
        }
        
        table.appendChild(row);
    }
});