let currentOperand = '0';
let previousOperand = '';
let operation = undefined;
let shouldResetScreen = false;

const currentOperandDisplay = document.querySelector('.current-operand');
const previousOperandDisplay = document.querySelector('.previous-operand');

function updateDisplay() {
    currentOperandDisplay.textContent = currentOperand;
    previousOperandDisplay.textContent = previousOperand;
}

function appendNumber(number) {
    if (shouldResetScreen) {
        currentOperand = '';
        shouldResetScreen = false;
    }
    if (number === '.' && currentOperand.includes('.')) return;
    if (currentOperand === '0' && number !== '.') {
        currentOperand = number;
    } else {
        currentOperand += number;
    }
    updateDisplay();
}

function clearAll() {
    currentOperand = '0';
    previousOperand = '';
    operation = undefined;
    updateDisplay();
}

function clearEntry() {
    currentOperand = '0';
    updateDisplay();
}

function backspace() {
    if (currentOperand.length === 1) {
        currentOperand = '0';
    } else {
        currentOperand = currentOperand.slice(0, -1);
    }
    updateDisplay();
}

function setOperation(op) {
    if (operation !== undefined) calculate();
    operation = op;
    previousOperand = currentOperand + ' ' + operation;
    shouldResetScreen = true;
    updateDisplay();
}

function calculate() {
    if (operation === undefined || shouldResetScreen) return;
    
    const prev = parseFloat(previousOperand);
    const current = parseFloat(currentOperand);
    let result;

    switch (operation) {
        case '+':
            result = prev + current;
            break;
        case '-':
            result = prev - current;
            break;
        case '×':
            result = prev * current;
            break;
        case '÷':
            if (current === 0) {
                alert('Деление на ноль невозможно');
                return;
            }
            result = prev / current;
            break;
    }

    currentOperand = result.toString();
    operation = undefined;
    previousOperand = '';
    shouldResetScreen = true;
    updateDisplay();
}

function negate() {
    currentOperand = (-parseFloat(currentOperand)).toString();
    updateDisplay();
}

function percent() {
    currentOperand = (parseFloat(currentOperand) / 100).toString();
    updateDisplay();
}

function sqrt() {
    if (parseFloat(currentOperand) < 0) {
        alert('Невозможно извлечь квадратный корень из отрицательного числа');
        return;
    }
    currentOperand = Math.sqrt(parseFloat(currentOperand)).toString();
    updateDisplay();
}

function inverse() {
    if (parseFloat(currentOperand) === 0) {
        alert('Деление на ноль невозможно');
        return;
    }
    currentOperand = (1 / parseFloat(currentOperand)).toString();
    updateDisplay();
}

function square() {
    currentOperand = (parseFloat(currentOperand) ** 2).toString();
    updateDisplay();
}