function calculateYears() {
    // Получаем значения из полей ввода
    const initialDebt = parseFloat(document.getElementById('initial').value);
    const targetDebt = parseFloat(document.getElementById('target').value);
    const resultDiv = document.getElementById('result');
    
    // Проверка корректности ввода
    if (isNaN(initialDebt) || isNaN(targetDebt)) {
        resultDiv.textContent = 'Пожалуйста, введите корректные числа';
        resultDiv.className = 'result error';
        return;
    }
    
    if (initialDebt <= 0 || targetDebt <= 0) {
        resultDiv.textContent = 'Суммы должны быть положительными';
        resultDiv.className = 'result error';
        return;
    }
    
    if (targetDebt <= initialDebt) {
        resultDiv.textContent = 'Целевая сумма должна быть больше начальной';
        resultDiv.className = 'result error';
        return;
    }

    // Расчет количества лет
    let years = 0;
    let currentDebt = initialDebt;
    const interestRate = 0.20; // 20% годовых

    while (currentDebt <= targetDebt) {
        currentDebt *= (1 + interestRate);
        years++;
    }

    // Форматирование результата
    const yearsText = formatYearsText(years);
    resultDiv.textContent = `Долг превысит ${targetDebt} тыс. руб. через ${years} ${yearsText}`;
    resultDiv.className = 'result success';
}

function formatYearsText(years) {
    const lastDigit = years % 10;
    const lastTwoDigits = years % 100;

    if (lastTwoDigits >= 11 && lastTwoDigits <= 14) {
        return 'лет';
    }

    if (lastDigit === 1) {
        return 'год';
    }

    if (lastDigit >= 2 && lastDigit <= 4) {
        return 'года';
    }

    return 'лет';
}