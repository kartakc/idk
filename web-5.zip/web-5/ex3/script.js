function analyzePath() {
    const input = document.getElementById('path').value.trim();
    const resultDiv = document.getElementById('result');
    const detailsDiv = document.getElementById('details');

    // Проверка на пустой ввод
    if (!input) {
        resultDiv.textContent = 'Пожалуйста, введите путь к файлу';
        resultDiv.className = 'result error';
        detailsDiv.textContent = '';
        return;
    }

    // Нормализуем разделители пути (заменяем обратные слеши на прямые)
    const normalizedPath = input.replace(/\\/g, '/');
    
    // Разбиваем путь на компоненты
    const components = normalizedPath.split('/').filter(component => component.length > 0);
    
    // Убираем последний элемент, если это файл
    const folders = components.slice(0, -1);

    // Формируем результат
    if (folders.length === 0) {
        resultDiv.textContent = 'В пути не найдены папки';
        resultDiv.className = 'result error';
        detailsDiv.textContent = '';
        return;
    }

    // Формируем подробное описание
    let details = 'Анализ пути:\n';
    details += `Исходный путь: ${input}\n`;
    details += `Нормализованный путь: ${normalizedPath}\n\n`;
    details += 'Найденные папки:\n';
    
    folders.forEach((folder, index) => {
        details += `${index + 1}. ${folder}\n`;
    });

    // Добавляем информацию о файле
    const fileName = components[components.length - 1];
    details += `\nИмя файла: ${fileName}`;

    // Выводим результат
    resultDiv.textContent = `Найдено папок: ${folders.length}`;
    resultDiv.className = 'result success';
    detailsDiv.innerHTML = details.replace(/\n/g, '<br>');
}

// Добавляем обработку нажатия Enter в поле ввода
document.getElementById('path').addEventListener('keypress', function(event) {
    if (event.key === 'Enter') {
        analyzePath();
    }
});