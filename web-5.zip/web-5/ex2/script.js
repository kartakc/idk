document.addEventListener('DOMContentLoaded', function() {
    const hoursGroup = document.querySelector('.hours');
    const minutesGroup = document.querySelector('.minutes');
    const secondsGroup = document.querySelector('.seconds');
    
    function updateClock() {
        const now = new Date();
        const hours = now.getHours();
        const minutes = now.getMinutes();
        const seconds = now.getSeconds();

        // Обновляем позиции цифр
        hoursGroup.style.transform = `translateY(${-hours * 60}px)`;
        minutesGroup.style.transform = `translateY(${-minutes * 60}px)`;
        secondsGroup.style.transform = `translateY(${-seconds * 60}px)`;
    }

    // Инициализируем часы сразу
    updateClock();
    
    // Обновляем время каждую секунду
    setInterval(updateClock, 1000);
});

function calculateYears() {
    // Получаем значения из полей ввода
    const initialDebt = parseFloat(document.getElementById('initial').value);
    const targetDebt = parseFloat(document.getElementById('target').value);
    const resultDiv = document.getElementById('result');
    
    // Проверка корректности ввода
    if (isNaN(initialDebt) || isNaN(targetDebt)) {
        resultDiv.textContent = 'Пожалуйста, введите корректные числа';
        resultDiv.className = 'result error';
        return;
    }
    
    if (initialDebt <= 0 || targetDebt <= 0) {
        resultDiv.textContent = 'Суммы должны быть положительными';
        resultDiv.className = 'result error';
        return;
    }
    
    if (targetDebt <= initialDebt) {
        resultDiv.textContent = 'Целевая сумма должна быть больше начальной';
        resultDiv.className = 'result error';
        return;
    }

    // Расчет количества лет
    let years = 0;
    let currentDebt = initialDebt;
    const interestRate = 0.20; // 20% годовых

    while (currentDebt <= targetDebt) {
        currentDebt *= (1 + interestRate);
        years++;
    }

    // Форматирование результата
    const yearsText = formatYearsText(years);
    resultDiv.textContent = `Долг превысит ${targetDebt} тыс. руб. через ${years} ${yearsText}`;
    resultDiv.className = 'result success';
}

function formatYearsText(years) {
    const lastDigit = years % 10;
    const lastTwoDigits = years % 100;

    if (lastTwoDigits >= 11 && lastTwoDigits <= 14) {
        return 'лет';
    }

    if (lastDigit === 1) {
        return 'год';
    }

    if (lastDigit >= 2 && lastDigit <= 4) {
        return 'года';
    }

    return 'лет';
}

function calculateSum() {
    // Получаем строку с числами и разбиваем её на массив
    const input = document.getElementById('array').value.trim();
    const resultDiv = document.getElementById('result');
    const detailsDiv = document.getElementById('details');

    // Проверяем, что ввод не пустой
    if (!input) {
        resultDiv.textContent = 'Пожалуйста, введите числа';
        resultDiv.className = 'result error';
        detailsDiv.textContent = '';
        return;
    }

    // Преобразуем строку в массив чисел
    const numbers = input.split(/\s+/).map(num => parseFloat(num));

    // Проверяем корректность ввода
    if (numbers.some(isNaN)) {
        resultDiv.textContent = 'Ошибка: введите только числа, разделенные пробелами';
        resultDiv.className = 'result error';
        detailsDiv.textContent = '';
        return;
    }

    // Находим последний элемент с отрицательным синусом
    let lastNegativeSinIndex = -1;
    for (let i = numbers.length - 1; i >= 0; i--) {
        if (Math.sin(numbers[i]) < 0) {
            lastNegativeSinIndex = i;
            break;
        }
    }

    // Если не найден элемент с отрицательным синусом
    if (lastNegativeSinIndex === -1) {
        resultDiv.textContent = 'В массиве нет чисел с отрицательным синусом';
        resultDiv.className = 'result error';
        detailsDiv.textContent = 'Синусы всех чисел положительные или равны нулю';
        return;
    }

    // Вычисляем сумму элементов от найденного индекса до конца массива
    const sum = numbers.slice(lastNegativeSinIndex).reduce((acc, curr) => acc + curr, 0);

    // Формируем подробное описание
    let details = `Найден элемент с отрицательным синусом: ${numbers[lastNegativeSinIndex]}\n`;
    details += `sin(${numbers[lastNegativeSinIndex]}) = ${Math.sin(numbers[lastNegativeSinIndex]).toFixed(4)}\n`;
    details += `Индекс элемента: ${lastNegativeSinIndex}\n`;
    details += `Суммируемые элементы: ${numbers.slice(lastNegativeSinIndex).join(', ')}`;

    // Выводим результат
    resultDiv.textContent = `Сумма элементов: ${sum.toFixed(2)}`;
    resultDiv.className = 'result success';
    detailsDiv.textContent = details;
}

function removeSpecialNumbers() {
    const input = document.getElementById('array').value.trim();
    const resultDiv = document.getElementById('result');
    const detailsDiv = document.getElementById('details');

    if (!input) {
        resultDiv.textContent = 'Пожалуйста, введите числа';
        resultDiv.className = 'result error';
        detailsDiv.textContent = '';
        return;
    }

    // Преобразуем строку в массив чисел
    let numbers = input.split(/\s+/).map(num => parseFloat(num));

    if (numbers.some(isNaN)) {
        resultDiv.textContent = 'Ошибка: введите только числа, разделенные пробелами';
        resultDiv.className = 'result error';
        detailsDiv.textContent = '';
        return;
    }

    // Сохраняем исходный массив для отображения
    const originalArray = [...numbers];

    // Фильтруем массив
    numbers = numbers.filter(num => !isAllDigitsPrime(Math.abs(Math.trunc(num))));

    // Формируем подробное описание
    let details = 'Исходный массив: ' + originalArray.join(', ') + '\n\n';
    details += 'Удалены числа:\n';
    
    originalArray.forEach(num => {
        const absInteger = Math.abs(Math.trunc(num));
        if (isAllDigitsPrime(absInteger)) {
            details += `${num} (целая часть: ${Math.trunc(num)}, ` +
                      `модуль: ${absInteger}, цифры: ${absInteger.toString().split('')})\n`;
        }
    });

    // Выводим результат
    resultDiv.textContent = `Результат: ${numbers.join(', ')}`;
    resultDiv.className = 'result success';
    detailsDiv.innerHTML = details.replace(/\n/g, '<br>');
}

// Проверка, является ли число простым
function isPrime(num) {
    if (num <= 1) return false;
    if (num <= 3) return true;
    if (num % 2 === 0 || num % 3 === 0) return false;
    
    for (let i = 5; i * i <= num; i += 6) {
        if (num % i === 0 || num % (i + 2) === 0) return false;
    }
    return true;
}

// Проверка, являются ли все цифры числа простыми
function isAllDigitsPrime(num) {
    // Преобразуем число в строку и проверяем каждую цифру
    return num.toString()
              .split('')
              .every(digit => isPrime(parseInt(digit)));
}