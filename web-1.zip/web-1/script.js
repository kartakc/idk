document.addEventListener('DOMContentLoaded', function() {
    // Список использованных HTML тегов
    const usedTags = [
        '!DOCTYPE', 'html', 'head', 'meta', 'title', 'link', 'body', 'header',
        'nav', 'main', 'section', 'h1', 'h2', 'h3', 'p', 'ul', 'li', 'ol',
        'img', 'table', 'thead', 'tbody', 'tr', 'th', 'td', 'pre', 'code',
        'footer', 'div', 'a'
    ];

    // Список использованных CSS свойств
    const usedProperties = [
        'font-family', 'font-size', 'line-height', 'color', 'max-width',
        'margin', 'padding', 'text-align', 'background-color', 'border-radius',
        'text-decoration', 'transition', 'max-width', 'height', 'box-shadow',
        'float', 'display', 'border-collapse', 'border', 'font-weight',
        'list-style-image', 'overflow-x', 'font-style', 'justify-content',
        'columns', 'list-style-type', 'position', 'transform', 'width',
        'background-image', 'background-size', 'background-repeat',
        'box-sizing', 'content', 'top', 'left', 'border-style',
        'white-space', 'vertical-align', 'overflow', 'outline', 
        'text-transform', 'column-count', 'box-shadow', 'opacity'
    ];

    // Заполняем список тегов
    const tagsList = document.querySelector('.tags-list');
    usedTags.forEach(tag => {
        const li = document.createElement('li');
        li.textContent = `<${tag}>`;
        tagsList.appendChild(li);
    });

    // Заполняем список CSS свойств
    const propertiesList = document.querySelector('.properties-list');
    usedProperties.forEach(prop => {
        const li = document.createElement('li');
        li.textContent = prop;
        propertiesList.appendChild(li);
    });
});